export default function Footer() {
    return (
        <div style={styles.footer}>
            <div style={styles.kepek}>
                <img src="public/assets/icons/facebook.svg" alt="facebook" />
                <img src="public/assets/icons/instagram.svg" alt="instagram" />
                <img src="public/assets/icons/twitter.svg" alt="twitter" />
                <img src="public/assets/icons/linkedin.svg" alt="linkedin" />
            </div>

            <p style={styles.leiras}>Copyright ©2020 All rights reserved</p>
        </div>
    );
}

const styles = {
    footer: {
        height: "182px",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        textAlign: "center",
        gap: "10px", 
    },
    leiras: {
        opacity: "60%",
        fontSize: "14px",
    },
    kepek: {
        display: "flex",
        gap: "40px", 
    },
};
